/*
* IT-265 Java Programming, Summer 2016
* Instructor: Martin P. Walsh
* Student Name: Natasha Ostrander
* Homework Assignment: Chap 1, Problem 6
* Purpose of Assignment: To compute the speed of a bicycle.
*
 */
package bicyclespeed;

/**
 *
 * @author Natasha Ostrander
 */
import java.util.Scanner;
import java.text.DecimalFormat;

public class BicycleSpeed {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Course Information
        System.out.println("IT-2650 Java Programming");
        System.out.println("Student Name: Natasha Ostrander");
        System.out.println("Homework Assignment: Chapter 1, Problem 6");
        System.out.println("________________________________");
        System.out.println("");
 
        double pi = 3.14;
        int gearSize; // Diameter of the wheel
        int cadence; //number of pedal revolutions per minute
        double speed; // Speed of the bicycle
        double ftPerInch = 0.08339; //Number of feet per inch (1/12) 
        double milesPerFt = 0.000189; //Number of miles per foot (1/5280)

        Scanner scannerObject = new Scanner(System.in);

        System.out.println("Enter the gear size in inches and the cadence: ");
        System.out.println("Separated by one or more spaces");

        gearSize = scannerObject.nextInt();
        cadence = scannerObject.nextInt();

        speed = (gearSize * pi) * (ftPerInch) * (milesPerFt) * cadence * 60;

        DecimalFormat formattingObject = new DecimalFormat("00.00");
        String finalSpeed = formattingObject.format(speed);
        System.out.println("The bicycle is going: " + finalSpeed + " mph.");

    }

}
